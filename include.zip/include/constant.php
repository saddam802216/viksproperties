<?php

    define('DIR_INCLUDE_PATH', 'include/');	
    define('BASE_URL', 'http://localhost/viksproperties/');
    define('ROOT_DIR', 'C:/xampp/htdocs/viksproperties/');
    define('UPLOAD_IMAGE_PATH', 'upload/project_sale_image/');
    define('UPLOAD_UNITINFO_IMAGE_PATH', 'upload/unit_info_image/');
    define('SITE_IMAGE_PATH', 'include/assets/img/');
    	

    define ("PROJECT_TITLE", serialize (array ("Select Option", "Project Title 1", "Project Title 2", "Project Title 3")));
    define ("LAYOUT", serialize (array ("Select Option", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" )));
    define ("ROAD_NAME", serialize (array ("Select Option", "Road Name 1", "Road Name 2", "Road Name 3")));
    define ("STATE", serialize (array ("Select Option", "state 1", "state 2", "state 3")));
    define ("CITY", serialize (array ("Select Option", "City 1", "City 2", "City 3")));
    define ("TENURE", serialize (array ("Select Option", "Tenure 1", "Tenure 2", "Tenure 3")));
    define ("RESERVE", serialize (array ("Select Option", "Reserve 1", "Reserve 2", "Reserve 3")));
    define ("COMMISSION", serialize (array ("Select Option", "Commission 1", "Commission 2", "Commission 3")));
    define ("POSTER_BANNER", serialize (array ("No", "Yes")));
    define ("LISTING_BY", serialize (array ("Select Option", "Listing By 1", "Listing By 2", "Listing By 3")));
    define ("BRINGIN_BY", serialize (array ("Select Option", "Bringin By 1", "Bringin By 2", "Bringin By 3")));
    define ("FACING", serialize (array ("Select Option", "Facing 1", "Facing 2", "Facing 3")));
    define ("CATEGORY", serialize (array ("Select Option", "Category 1", "Category 2", "Category 3")));
    define ("TYPE", serialize (array ("Select Option", "Type 1", "Type 2", "Type 3")));
    define ("CONCEPT", serialize (array ("Select Option", "Concept 1", "Concept 2", "Concept 3")));
    define ("ROOM", serialize (array ("Select Option", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10")));
    define ("BATHROOM", serialize (array ("Select Option", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10")));
    define ("FLOORING", serialize (array ("Select Option", "Flooring 1", "Flooring 2", "Flooring 3")));
    define ("STATUS", serialize (array ("Select Option", "Status 1", "Status 2", "Status 3")));
    define ("AGENT", serialize (array ("Select Option", "Agent 1", "Agent 2", "Agent 3")));



    
    
?>