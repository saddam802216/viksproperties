
    $(document).ready(function(){
        $(document).on('change', '#layout', function(){
            let count = $(this).val();
            count = count-1;
            console.log("count : ", count);
            $('div.card li.navItemTab').hide();        
            $('div.card li.navItemTab:lt('+count+')').show();
        });
    });


    
    // $(document).ready(function(){
    //     $(document).on('change', '#layout', function(){
    //         let count = $(this).val();
    //         let layout = $('#unitInfo .unitInfoFormBody:first').html();
    //         let preLayout = $('.unitInfoFormBody').length;
    //         if(preLayout>1) {
    //             $('.unitInfoFormBody').not('.unitInfoFormBody:first').remove();
    //         }
    //         let newLayout = '<div class="p-20 w-85 border unitInfoFormBody" style="margin-top:15px; border-top: solid 2px #b1b1b1; padding-top: 30px;">'+layout+'</div>';
    //         for(i=0; i<count-1; i++) {
    //             $('#unitInfo .unitInfoFormBody:last').after(newLayout);
    //             $('#unitInfo .unitInfoFormBody:last h4').text('Layout '+(i+2));
    //             $('#unitInfo .unitInfoFormBody:last .unitinfo_photo_upload').attr('name', 'unitinfo_photo_upload['+(i+1)+'][]');
    //         }
    //     });
    // });



    
    // $(document).ready(function(){
    //     $(document).on('change', '#layout', function(){
    //         let count = $(this).val();
    //         count--;
    //         $('div.card li.navItemTab').hide();        
    //         $('div.card li.navItemTab:lt(count)').show();
            
            
    //     });
    // });
