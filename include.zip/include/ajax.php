<?php

require_once('include.php');

$data = $_POST;

if($data['task']=='getStatusData') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Status not Found';
    $modalBodyHtml = '';
    
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];

    $query = "SELECT * FROM `tbl_unitlogs` WHERE layout_id='".$layout_id."' AND pno='".$pno."' ORDER BY log_id DESC LIMIT 1";
    $result = $con->query($query);
    if($result->num_rows > 0){
        $log = $result->fetch_object();

        $obj->success = true;
        $obj->message = 'Status Found';
        // Get loging User
        $loginUserId = Helper::getLoginUser();
        $loginUser = Helper::getUserById($loginUserId);
        if($log->remarks=='Booking') {
            if($log->user_id==$loginUserId || $loginUser->admin_group=='ADMIN' || $loginUser->admin_group=='SYS_ADMIN') {
                $modalBodyHtml .= '<h5>Would you like to cancel booking this unit?</h5>
                <input type="submit" class="btn btn-primary updateStatusSubmit" value="Cancel Booking">';
                if(isset($log->log_remarks) && !empty($log->log_remarks)) {
                    $modalBodyHtml .= '<h5>Remarks : '.$log->log_remarks.'</h5>';
                }
            }else{
                $bookedUser = Helper::getUserById($log->user_id);
                $bookedUserName = $bookedUser->admin_firstname;
                $modalBodyHtml .= '<h5> This Unit is booked by '.$bookedUserName.'</h5>'; 
                if(isset($log->log_remarks) && !empty($log->log_remarks)) {
                    $modalBodyHtml .= '<h5>Remarks : '.$log->log_remarks.'</h5>';
                }  
            }
        }else{
            $modalBodyHtml .= '<h5>Would you like to booking this unit?</h5>
            <input type="submit" class="btn btn-primary updateStatusSubmit" value="Booking"><p style="padding-top:10px;">Remarks</p><textarea name="log_remarks" id="log_remarks" class="log_remarks"></textarea>';
        }
    }else{
        $modalBodyHtml .= '<h5>Would you like to booking this unit?</h5>
        <input type="submit" class="btn btn-primary updateStatusSubmit" value="Booking"><p style="padding-top:10px;">Remarks</p><textarea name="log_remarks" id="log_remarks" class="log_remarks"></textarea>';
    }

    $obj->modalBody = $modalBodyHtml;
    exit(json_encode($obj));
}

if($data['task']=='updateStatus') {
    // prx($data);
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Status not update';
    $log_id = '';
    $date = date("Y-m-d");
    $remarks = $data['remarks'];
    $user_id = Helper::getLoginUser();
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];
    $project_id = $data['project_id'];
    $log_remarks = $data['log_remarks'];

    $query = "INSERT INTO `tbl_unitlogs` (log_id, date, remarks, user_id, pno, layout_id, project_id, log_remarks) VALUES('".$log_id."', '".$date."', '".$remarks."', '".$user_id."', '".$pno."', '".$layout_id."', '".$project_id."', '".$log_remarks."')";
    if ($con->query($query)) {
        $obj->success = true;
        $obj->message = 'Status update successfully';
        $obj->status = $remarks;
        $obj->date = $date;
        $user = Helper::getUserById($user_id);
        $obj->agent = $user->admin_firstname;
    } 

    // prx($con->error);

    exit(json_encode($obj));
}

if($data['task']=='getUnitLog') {
    
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Log not found';
    $obj->html = '';
    $pno = $data['pno'];
    $layout_id = $data['layout_id'];
    $project_id = $data['project_id'];
    $logs = array();

    $query = "SELECT ul.*, u.admin_firstname AS user_name FROM `tbl_unitlogs` AS ul LEFT JOIN `administrators` AS u on ul.user_id=u.admin_id WHERE project_id='".$project_id."' AND layout_id='".$layout_id."' AND pno='".$pno."' ORDER BY log_id DESC";
    $result = $con->query($query);
    if($result->num_rows > 0){
        while($res = $result->fetch_object()) {
            $logs[] = $res;			 
        }
    }

    if(!empty($logs)) {
        $logHtml = '';
        foreach($logs as $key=>$log) {
            $index = $key+1;
            $logHtml .= '<tr>
            <th scope="row">'.$index.'</th>
            <td>'.$log->date.'</td>
            <td>'.$log->remarks.'</td>
            <td>'.$log->user_name.'</td>
            </tr>'; 
        }
        $obj->html = $logHtml;
        $obj->success = true;
        $obj->message = 'Logs Available'; 
    }else {
        $obj->html = '<tr><td colspan="4"><h5 style="text-align:center"> Log not available </h5></td></tr>';
    }
    // prx($obj);
    exit(json_encode($obj));
}

// Update Sale Info

if($data['task']=='updateSaleInfo') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Data not update';
    $form_data = array();
    parse_str($data['saleFormData'], $form_data);

    $property_id = $form_data['property_id'];
    // $listing_type = 'Project Sale';
    $project_title = $form_data['project_title'];
    $layout = $form_data['layout'];
    $road_name = $form_data['road_name'];
    $state = $form_data['state'];
    $city = $form_data['city'];
    $tenure = $form_data['tenure'];
    $reserve = $form_data['reserve'];
    $commission = $form_data['commission'];
    $poster_banner = $form_data['poster_banner'];
    $ads_date = $form_data['ads_date'];
    $remarks = $form_data['remarks'];
    $listing_date = $form_data['listing_date'];
    $listing_by = $form_data['listing_by'];
    $bringin_by = $form_data['bringin_by'];
    
    $query = "UPDATE `tbl_projectsaleinfo` SET `project_title`='".$project_title."', `layout`='".$layout."', `road_name`='".$road_name."', `state`='".$state."', `city`='".$city."', `tenure`='".$tenure."', `reserve`='".$reserve."', `commission`='".$commission."', `poster_banner`='".$poster_banner."', `ads_date`='".$ads_date."', `remarks`='".$remarks."', `listing_date`='".$listing_date."', `listing_by`='".$listing_by."', `bringin_by`='".$bringin_by."' WHERE property_id='".$property_id."'";
    if($con->query($query) === TRUE) {
        // Store Uploaded Photoes in table
        $files = $_FILES;
        if($files) {
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($files["files"]["name"]); $i++ ) {
                $extension = explode(".", $files["files"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['files']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = '';
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($form_data['general_info_cover_photo']) && ($form_data['general_info_cover_photo']==$files["files"]["name"][$i]) ) ? 1 : 0;
                        
                        // Remove cover photo on upload new cover photo
                        if($file_cover) {
                            $query1 = "UPDATE `tbl_projectsaleimage` SET `file_cover`='0' WHERE property_id='".$property_id."'";
                            $con->query($query1);
                        }
                        
                        $property_id = $property_id;
                        $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";

                        if (!$con->query($query)) {
                            continue;
                        } 

                        // Watermark ---------------------------------------------------

                        $varPhoto = "files";
                        $target_path = $imgPath;
                        /*code for watermark and resizing image starts here*/
                                            
                        $max_size = 800; //max image size in Pixels
                        $destination_folder = 'upload/temp';
                        $watermark_png_file = ROOT_DIR.SITE_IMAGE_PATH.'watermark.png'; //path to watermark image
                        
                        $image_name =$_FILES[$varPhoto]['name'][$i]; //file name
                        $image_size = $_FILES[$varPhoto]['size'][$i]; //file size
                        $image_temp = $_FILES[$varPhoto]['tmp_name'][$i]; //file temp
                        $image_type = $_FILES[$varPhoto]['type'][$i]; //file type

                        switch(strtolower($image_type)){ //determine uploaded image type
                                //Create new image from file
                            case 'image/png':
                                $image_resource =  imagecreatefrompng($target_path);
                                break;
                            case 'image/gif':
                                $image_resource =  imagecreatefromgif($target_path);
                                break;          
                            case 'image/jpeg': case 'image/pjpeg':
                                $image_resource = imagecreatefromjpeg($target_path);
                                break;
                            default:
                                $image_resource = false;
                        }
        
                        if($image_resource){
                            //Copy and resize part of an image with resampling
                            list($img_width, $img_height) = getimagesize($target_path);
                        
            
                            //Construct a proportional size of new image
                            $image_scale        = min($max_size / $img_width, $max_size / $img_height);
                            $new_image_width    = ceil($image_scale * $img_width);
                            $new_image_height   = ceil($image_scale * $img_height);
                            
                            $new_canvas = imagecreatetruecolor($new_image_width , $new_image_height);

                            //Resize image with new height and width
                            if(imagecopyresampled($new_canvas, $image_resource , 0, 0, 0, 0, $new_image_width, $new_image_height, $img_width, $img_height))
                            {
                                // if(!is_dir($destination_folder)){
                                //     mkdir($destination_folder);//create dir if it doesn't exist
                                // }
                            
                                //calculate center position of watermark image
                                $watermark_left = ($new_image_width/2)-(264/2); //watermark left
                                $watermark_bottom = ($new_image_height/2)-(166/2); //watermark bottom

                                $watermark = imagecreatefrompng($watermark_png_file); //watermark image

                                //use PHP imagecopy() to merge two images.
                                imagecopy($new_canvas, $watermark, $watermark_left, $watermark_bottom, 0, 0, 263, 165); //merge image
                            
                                //output image direcly on the browser.
                                //header('Content-Type: image/jpeg');
                            //  imagejpeg($new_canvas, NULL , 90);
                            
                                //Or Save image to the folder
                                imagejpeg($new_canvas,  $target_path, 90);
                            
                                //free up memory
                                imagedestroy($new_canvas);
                                imagedestroy($image_resource);
                            }
                        }
                        // End Watermark --------------------------------------------------
                    }
                }
            }
        }

        // Add or update YouTube video
        if(isset($form_data['sale_youtube_video']) && !empty($form_data['sale_youtube_video'])) {
            $query = "SELECT * FROM `tbl_projectsaleimage` WHERE property_id='".$property_id."' AND file_type='VIDEO'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                // Update YouTube video
                $query = "UPDATE `tbl_projectsaleimage` SET `file_name`='".$form_data['sale_youtube_video']."' WHERE property_id='".$property_id."' AND file_type='VIDEO'";
            }else {
                // Add YouTube video
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $form_data['sale_youtube_video'];
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
            }
            $con->query($query);
        }


        $obj->success = true;
        $obj->message = 'Data update successfully';
        $obj->url = BASE_URL.'index.php?page=projectsale_edit&id='.$property_id.'&layout=1';
    }
    exit(json_encode($obj));
}


// Update unit info


if($data['task']=='updateUnitInfo') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Data not update';
    $obj->imageHtml = '';
    $form_data = array();
    parse_str($data['unitInfoFormData'], $form_data);
    
    $unit_id = $form_data['unitInfo_id'];
    $pno = $form_data['pno'];
    $facing = $form_data['facing'];
    $land_area = $form_data['land_area'];
    $built_up = $form_data['built_up'];
    $category = $form_data['category'];
    $type = $form_data['type'];
    $concept = $form_data['concept'];
    $room = $form_data['room'];
    $bathroom = $form_data['bathroom'];
    $flooring = $form_data['flooring'];
    $snp_price = $form_data['s&p_price'];
    $promotion_price = $form_data['promotion_price'];
    // prx($form_data);
    if(!empty($unit_id)) {
        $query = "UPDATE `tbl_projectsalesunitinfo` SET `pno`='".$pno."', `facing`='".$facing."', `land_area`='".$land_area."', `built_up`='".$built_up."', `category`='".$category."', `type`='".$type."', `concept`='".$concept."', `room`='".$room."', `bathroom`='".$bathroom."', `flooring`='".$flooring."', `snp_price`='".$snp_price."', `promotion_price`='".$promotion_price."' WHERE unit_id='".$unit_id."'";
    }else{
        $unit_id = '';
        $property_id = $form_data['property_id'];
        $query = "INSERT INTO `tbl_projectsalesunitinfo` (unit_id, property_id, pno, facing, land_area, built_up, category, type, concept, room, bathroom, flooring, snp_price, promotion_price) VALUES ('".$unit_id."', '".$property_id."', '".$pno."', '".$facing."', '".$land_area."', '".$built_up."', '".$category."', '".$type."', '".$concept."', '".$room."', '".$bathroom."', '".$flooring."', '".$snp_price."', '".$promotion_price."')";
    }
    
    if($con->query($query) === TRUE) {
        // Store Uploaded Photoes in table
        if(empty($unit_id)) {
            $unit_id = $con->insert_id;
        }
        $files = $_FILES;
        if($files) {
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($files["files"]["name"]); $i++ ) {
                $extension = explode(".", $files["files"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['files']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_UNITINFO_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = '';
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($form_data['unit_info_cover_photo']) && ($form_data['unit_info_cover_photo']==$files["files"]["name"][$i]) ) ? 1 : 0;
                        
                        // Remove cover photo on upload new cover photo
                        if($file_cover) {
                            $query = "UPDATE `tbl_projectsalesunitimage` SET `file_cover`='0' WHERE unit_id='".$unit_id."'";
                            $con->query($query);
                        }
                        
                        $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";

                        if (!$con->query($query)) {
                            continue;
                        } 

                        // Watermark ---------------------------------------------------

                        $varPhoto = "files";
                        $target_path = $imgPath;
                        /*code for watermark and resizing image starts here*/
                                            
                        $max_size = 800; //max image size in Pixels
                        $destination_folder = 'upload/temp';
                        $watermark_png_file = ROOT_DIR.SITE_IMAGE_PATH.'watermark.png'; //path to watermark image
                        
                        $image_name =$_FILES[$varPhoto]['name'][$i]; //file name
                        $image_size = $_FILES[$varPhoto]['size'][$i]; //file size
                        $image_temp = $_FILES[$varPhoto]['tmp_name'][$i]; //file temp
                        $image_type = $_FILES[$varPhoto]['type'][$i]; //file type

                        switch(strtolower($image_type)){ //determine uploaded image type
                                //Create new image from file
                            case 'image/png':
                                $image_resource =  imagecreatefrompng($target_path);
                                break;
                            case 'image/gif':
                                $image_resource =  imagecreatefromgif($target_path);
                                break;          
                            case 'image/jpeg': case 'image/pjpeg':
                                $image_resource = imagecreatefromjpeg($target_path);
                                break;
                            default:
                                $image_resource = false;
                        }
        
                        if($image_resource){
                            //Copy and resize part of an image with resampling
                            list($img_width, $img_height) = getimagesize($target_path);
                        
            
                            //Construct a proportional size of new image
                            $image_scale        = min($max_size / $img_width, $max_size / $img_height);
                            $new_image_width    = ceil($image_scale * $img_width);
                            $new_image_height   = ceil($image_scale * $img_height);
                            
                            $new_canvas = imagecreatetruecolor($new_image_width , $new_image_height);

                            //Resize image with new height and width
                            if(imagecopyresampled($new_canvas, $image_resource , 0, 0, 0, 0, $new_image_width, $new_image_height, $img_width, $img_height))
                            {
                                // if(!is_dir($destination_folder)){
                                //     mkdir($destination_folder);//create dir if it doesn't exist
                                // }
                            
                                //calculate center position of watermark image
                                $watermark_left = ($new_image_width/2)-(300/2); //watermark left
                                $watermark_bottom = ($new_image_height/2)-(100/2); //watermark bottom

                                $watermark = imagecreatefrompng($watermark_png_file); //watermark image

                                //use PHP imagecopy() to merge two images.
                                imagecopy($new_canvas, $watermark, $watermark_left, $watermark_bottom, 0, 0, 263, 165); //merge image
                            
                                //output image direcly on the browser.
                                //header('Content-Type: image/jpeg');
                            //  imagejpeg($new_canvas, NULL , 90);
                            
                                //Or Save image to the folder
                                imagejpeg($new_canvas,  $target_path, 90);
                            
                                //free up memory
                                imagedestroy($new_canvas);
                                imagedestroy($image_resource);
                            }
                        }
                        // End Watermark --------------------------------------------------
                    }
                }
            }

            // get unit image 
            $imageHtml = '';
            $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$unit_id."' AND file_type='IMAGE'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                while($res = $result->fetch_object()) {
                    $coverPhotoClass = '';
                    $coverPhoto_tooltip = '';
                    if($res->file_cover) {
                        $coverPhotoClass = 'cover-photo';
                        $coverPhoto_tooltip = 'data-toggle="tooltip" title="Cover Photo!"';
                    }
                    $imageHtml .= '<div class="col-sm-3 col-xs-6 image-main '.$coverPhotoClass.'" style="padding-top: 10px;">
                    <a href="javascript::void()" class="removeImage" data-id="'.$res->file_id.'" data-type="unit" '.$coverPhoto_tooltip.'><i class="fa fa-times fa-1x "></i></a>
                    <img src="'.BASE_URL.UPLOAD_UNITINFO_IMAGE_PATH.$res->file_name.'" alt="Los Angeles" style="width:100%; height:60px" class="img-main">
                </div>';			 
                }
            }
            $obj->imageHtml = $imageHtml;
        }

        // Add or update YouTube video
        if(isset($form_data['unit_youtube_video']) && !empty($form_data['unit_youtube_video'])) {
            $query = "SELECT * FROM `tbl_projectsalesunitimage` WHERE unit_id='".$unit_id."' AND file_type='VIDEO'"; 
            $result = $con->query($query);
            if($result->num_rows > 0){
                // Update YouTube video
                $query = "UPDATE `tbl_projectsalesunitimage` SET `file_name`='".$form_data['unit_youtube_video']."' WHERE unit_id='".$unit_id."' AND file_type='VIDEO'";
            }else {
                // Add YouTube video
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $form_data['unit_youtube_video'];
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";
            }
            $con->query($query);
        }

        $obj->success = true;
        $obj->unit_id = $unit_id;
        $obj->message = 'Data update successfully';
    }
    exit(json_encode($obj));
}

// Remove Image

if($data['task']=='removeImage') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Image not remove';

    if( isset($data['id']) && !empty($data['id']) && isset($data['type']) && !empty($data['type']) ) {
        $table = '';
        if($data['type']=='sale') {
            $table = 'tbl_projectsaleimage';
        }elseif($data['type']=='unit') {
            $table = 'tbl_projectsalesunitimage';
        }
        $query = "DELETE FROM `".$table."` WHERE file_id='".$data['id']."'";
        if($con->query($query) === TRUE) {
            $obj->success = true;
            $obj->message = 'Image has been removed';
        }
    }
    
    exit(json_encode($obj));
}

// Update Cover Photo

if($data['task']=='updateCoverPhoto') {
    $obj = new stdClass();
    $obj->success = false;
    $obj->message = 'Image not updated';

    if( isset($data['field_id']) && !empty($data['field_id']) && isset($data['file_id']) && !empty($data['file_id']) && isset($data['type']) && !empty($data['type']) ) {
        $table = '';
        $fieldName = '';
        if($data['type']=='sale') {
            $table = 'tbl_projectsaleimage';
            $fieldName = 'property_id';
        }elseif($data['type']=='unit') {
            $table = 'tbl_projectsalesunitimage';
            $fieldName = 'unit_id';
        }
        
        $query = "UPDATE `".$table."` SET `file_cover`='0' WHERE ".$fieldName."='".$data['field_id']."'";
        if($con->query($query)) {
            $query = "UPDATE `".$table."` SET `file_cover`='1' WHERE file_id='".$data['file_id']."'";
            if($con->query($query) === TRUE) {
                $obj->success = true;
                $obj->message = 'Image updated';
            }
        }
    }
    
    exit(json_encode($obj));
}

?>