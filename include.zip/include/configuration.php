<?php

	// $con = mysql_connect(DB_SERVER,DB_SERVER_USERNAME,DB_SERVER_PASSWORD);
	// if (!$con) {
	// 	die('Could not connect: ' . mysql_error());
	// }
	// mysql_select_db(DB_DATABASE) or die('Could not select database');
	
	
	
?>
