<?php
require_once('include.php');

$data = $_POST;
session_start();
// prx($data);

$isLogout = ( isset($_GET['task']) && $_GET['task']=='logout' ) ? $_GET['task'] : '';
if($isLogout) {
    session_destroy();
    header('Location: '.BASE_URL.'index.php');
}

if(isset($data['login'])) {
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';

    $email = $data['email'];
    $password = md5($data['password']);
    $sql = "SELECT * FROM administrators WHERE admin_email='".$email."'";
    $result = $con->query($sql);
    
	if($result->num_rows > 0){
        $sql = "SELECT * FROM administrators WHERE admin_email='".$email."' AND admin_password='".$password."' AND admin_status=1";
        $result = $con->query($sql);
        if($result->num_rows > 0){
            $sql = "SELECT * FROM administrators WHERE admin_email='".$email."' AND admin_password='".$password."'";
            while($user = $result->fetch_assoc()) {
                session_start();
                $_SESSION['user'] = $user;			 
            }
            if(isset($data['remember']) && !empty($data['remember'])) {
                $hour = time() + 3600 * 24 * 30;
                setcookie('email', $email, $hour);
                setcookie('password', $password, $hour);
                setcookie('remember_me', '1', $hour);
            }
            header('Location: '.BASE_URL.'index.php');
            exit;
        }else{
            $obj->status = false;
            $obj->message = "Entered wrong password!";
            $_SESSION['login'] = $obj;
            header('Location: '.BASE_URL.'index.php');	
            exit;
        }
	}else{
        $obj->status = false;
        $obj->message = "User not registerd, Please register first!";
        $_SESSION['login'] = $obj;
        
        header('Location: '.BASE_URL.'index.php');
        
        exit;
	}
}

if(isset($data['submit_projectsale'])) {
    
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';
    // Store data in table
    $property_id = null;
    $listing_type = 'Project Sale';
    $project_title = $data['project_title'];
    $road_name = $data['road_name'];
    $state = $data['state'];
    $layout = $data['layout'];
    $city = $data['city'];
    $tenure = $data['tenure'];
    $reserve = $data['reserve'];
    $commission = $data['commission'];
    $poster_banner = $data['poster_banner'];
    $ads_date = $data['ads_date'];
    $remarks = $data['remarks'];
    $listing_date = $data['listing_date'];
    $listing_by = $data['listing_by'];
    $bringin_by = $data['bringin_by'];

    $file = $_FILES;
    //$photo_uplaod = ( isset($file['photo_upload']) && !empty($file['photo_upload']) ) ? 1 : 0;

    $query = "INSERT INTO `tbl_projectsaleinfo` (property_id, listing_type, project_title, road_name, state, layout, city, tenure, reserve, commission, poster_banner, ads_date, remarks, listing_date, listing_by, bringin_by) VALUES ('', '".$listing_type."', '".$project_title."', '".$road_name."', '".$state."', '".$layout."', '".$city."', '".$tenure."', '".$reserve."', '".$commission."', '".$poster_banner."', '".$ads_date."', '".$remarks."', '".$listing_date."', '".$listing_by."', '".$bringin_by."')";
    $res = $con->query($query);
    
    if ($res === TRUE) {
        $property_id = $con->insert_id;
        if(!empty($property_id)) {
            // Store Uploaded Photoes in table
            $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
            $videoExts = array("webm", "mp4", "ogv");
            for( $i=0; $i<count($file["photo_upload"]["name"]); $i++ ) {
                $extension = explode(".", $file["photo_upload"]["name"][$i]);
                $extension = end($extension);
                $src = $_FILES['photo_upload']['tmp_name'][$i];
                
                if ( in_array($extension, $allowedExts) ) {
            
                    $time = time();
                    $rand=rand(10000,999999999);
                    $encname=$time.$rand;
                    $imgName=$encname.'.'.$extension;
                    $imgPath=ROOT_DIR.UPLOAD_IMAGE_PATH.$imgName;
                    if(move_uploaded_file($src, $imgPath)) {
                    
                        $file_id = null;
                        $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                        $file_name = $imgName;
                        $file_cover = ( isset($data['general_info_cover_photo']) && ($data['general_info_cover_photo']==$file["photo_upload"]["name"][$i]) ) ? 1 : 0;
                        // $file_cover = '';
                        $property_id = $property_id;
                        $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
    
                        if (!$con->query($query)) {
                            continue;
                        } 

                        // Watermark ---------------------------------------------------

                        $varPhoto = "photo_upload";
                        $target_path = $imgPath;
                        /*code for watermark and resizing image starts here*/
                                            
                        $max_size = 800; //max image size in Pixels
                        $destination_folder = 'upload/temp';
                        $watermark_png_file = ROOT_DIR.SITE_IMAGE_PATH.'watermark.png'; //path to watermark image
                        
                        $image_name =$_FILES[$varPhoto]['name'][$i]; //file name
                        $image_size = $_FILES[$varPhoto]['size'][$i]; //file size
                        $image_temp = $_FILES[$varPhoto]['tmp_name'][$i]; //file temp
                        $image_type = $_FILES[$varPhoto]['type'][$i]; //file type

                        switch(strtolower($image_type)){ //determine uploaded image type
                                //Create new image from file
                            case 'image/png':
                                $image_resource =  imagecreatefrompng($target_path);
                                break;
                            case 'image/gif':
                                $image_resource =  imagecreatefromgif($target_path);
                                break;          
                            case 'image/jpeg': case 'image/pjpeg':
                                $image_resource = imagecreatefromjpeg($target_path);
                                break;
                            default:
                                $image_resource = false;
                        }
        
                        if($image_resource){
                            //Copy and resize part of an image with resampling
                            list($img_width, $img_height) = getimagesize($target_path);
                        
            
                            //Construct a proportional size of new image
                            $image_scale        = min($max_size / $img_width, $max_size / $img_height);
                            $new_image_width    = ceil($image_scale * $img_width);
                            $new_image_height   = ceil($image_scale * $img_height);
                            
                            $new_canvas = imagecreatetruecolor($new_image_width , $new_image_height);

                            //Resize image with new height and width
                            if(imagecopyresampled($new_canvas, $image_resource , 0, 0, 0, 0, $new_image_width, $new_image_height, $img_width, $img_height))
                            {
                                // if(!is_dir($destination_folder)){
                                //     mkdir($destination_folder);//create dir if it doesn't exist
                                // }
                            
                                //calculate center position of watermark image
                                $watermark_left = ($new_image_width/2)-(300/2); //watermark left
                                $watermark_bottom = ($new_image_height/2)-(100/2); //watermark bottom

                                $watermark = imagecreatefrompng($watermark_png_file); //watermark image

                                //use PHP imagecopy() to merge two images.
                                imagecopy($new_canvas, $watermark, $watermark_left, $watermark_bottom, 0, 0, 263, 165); //merge image
                            
                                //output image direcly on the browser.
                                //header('Content-Type: image/jpeg');
                            //  imagejpeg($new_canvas, NULL , 90);
                            
                                //Or Save image to the folder
                                imagejpeg($new_canvas,  $target_path, 90);
                            
                                //free up memory
                                imagedestroy($new_canvas);
                                imagedestroy($image_resource);
                            }
                        }
                        // End Watermark --------------------------------------------------
                    }
                }
            }

            // Add YouTube video 
            $youtube_video = $data['sale_youtube_video'];
            if($youtube_video) {
                $file_id = '';
                $file_type = 'VIDEO';
                $file_name = $youtube_video;
                $file_cover = 0;
                $query = "INSERT INTO `tbl_projectsaleimage` (file_id, file_type, file_name, file_cover, property_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$property_id."')";
                $con->query($query);
            }


            // Store data in unitinfo table

            // for($i=0; $i<$layout; $i++) {
                if(false) {
                $unit_id = '';
                $property_id = $property_id;
                $pno = $data['pno'][$i];
                // if(empty($pno))
                // continue;
                $facing = $data['facing'][$i];
                $land_area = $data['land_area'][$i];
                $built_up = $data['built_up'][$i];
                $category = $data['category'][$i];
                $type = $data['type'][$i];
                $concept = $data['concept'][$i];
                $room = $data['room'][$i];
                $bathroom = $data['bathroom'][$i];
                $flooring = $data['flooring'][$i];
                $snp_price = $data['s&p_price'][$i];
                $promotion_price = $data['promotion_price'][$i];
                
                // $unitinfo_photo_upload = ( isset($file['unitinfo_photo_upload']['name'][$i]) && !empty($file['unitinfo_photo_upload']['name'][$i]) ) ? 1 : 0;
                // $unitinfo_video_link = $data['unitinfo_video_link'][$i];

                $query = "INSERT INTO `tbl_projectsalesunitinfo` (unit_id, property_id, pno, facing, land_area, built_up, category, type, concept, room, bathroom, flooring, snp_price, promotion_price) VALUES ('".$unit_id."', '".$property_id."', '".$pno."', '".$facing."', '".$land_area."', '".$built_up."', '".$category."', '".$type."', '".$concept."', '".$room."', '".$bathroom."', '".$flooring."', '".$snp_price."', '".$promotion_price."')";
                $res = $con->query($query);
                
                if ($res === TRUE) {
                    $unit_id = $con->insert_id;
                    if(!empty($unit_id)) {
                        // Store Uploaded Photoes in table
                        $allowedExts = array("png","jpg","jpeg","webm", "mp4", "ogv");
                        $videoExts = array("webm", "mp4", "ogv");
                        for( $j=0; $j<count($file["unitinfo_photo_upload"]["name"][$i]); $j++ ) {
                            $extension = explode(".", $file["unitinfo_photo_upload"]["name"][$i][$j]);
                            $extension = end($extension);
                            $src = $_FILES['unitinfo_photo_upload']['tmp_name'][$i][$j];
                            
                            if ( in_array($extension, $allowedExts) ) {
                        
                                $time = time();
                                $rand=rand(10000,999999999);
                                $encname=$time.$rand;
                                $imgName=$encname.'.'.$extension;
                                $imgPath=ROOT_DIR.UPLOAD_UNITINFO_IMAGE_PATH.$imgName;
                                if(move_uploaded_file($src, $imgPath)) {
                                
                                    $file_id = '';
                                    $file_type = $file_type = ( in_array($extension, $videoExts) )?'VIDEO':'IMAGE';
                                    $file_name = $imgName;
                                    $file_cover = ( isset($data['unit_info_cover_photo'][$i]) && ($data['unit_info_cover_photo'][$i]==$file["unitinfo_photo_upload"]["name"][$i][$j]) ) ? 1 : 0;
                                    $unit_id = $unit_id;
                                    $query = "INSERT INTO `tbl_projectsalesunitimage` (file_id, file_type, file_name, file_cover, unit_id) VALUES ('".$file_id."', '".$file_type."', '".$file_name."', '".$file_cover."', '".$unit_id."')";
                
                                    if (!$con->query($query)) {
                                        continue;
                                    } 
                                }
                            }
                        }
                    }
                }
            }
        }
        header('Location: '.BASE_URL.'index.php?page=projectsale_edit&id='.$property_id.'&layout=1');
        exit;
    }
    header('Location: '.BASE_URL.'index.php?page=projectsale');
}
if(isset($data['submit_save_password'])) {
    $obj = new stdClass;
    $obj->status = true;
    $obj->message = '';
    
    if($data['submit_save_password']) {
        $password = $data['password'];
        $currentDate = date('Y-m-d');
        $userid = Helper::getUserId();
        
        $query = "UPDATE `users` SET  `password`='".$password."', `modified`='".$currentDate."' WHERE id='".$userid."'";
        
        if ($conn->query($query) === TRUE) {
            header('Location: login.php');
            exit;
        }
    }

    $obj->status = false;
    $obj->message = 'File not uploaded!';
    header('Location: password.php');
    exit;

}


?>